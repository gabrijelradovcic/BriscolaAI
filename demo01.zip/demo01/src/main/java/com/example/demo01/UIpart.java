package com.example.demo01;

import javafx.scene.*;
import javafx.scene.control.Button;  //forSetOnAction

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
public class UIpart extends Application {
    Double startX, startY;
    Double cardWidth = 63*1.5, cardHeight = 88*1.5;
    Color tableColor = Color.rgb(0,66,37);

    ArrayList<InputStream> isList = new ArrayList<InputStream>();
    ArrayList<ImageView> ImageViewList = new ArrayList<ImageView>();
    ArrayList<Rectangle> cards = new ArrayList<Rectangle>();
    ArrayList<ImageView> cardPlayer1 = new ArrayList<ImageView>();
    ArrayList<ImageView> cardPlayer2 = new ArrayList<ImageView>();



    public static void main(String args[]) {

        launch(args);
    }




    public void start(Stage stage) throws IOException {
        InputStream streamA01 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A01.png");
        InputStream streamA02 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A02.png");
        InputStream streamA03 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A03.png");
        InputStream streamA04 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A04.png");
        InputStream streamA05 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A05.png");
        InputStream streamA06 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A06.png");
        InputStream streamA07 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A07.png");
        InputStream streamA08 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A08.png");
        InputStream streamA09 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A09.png");
        InputStream streamA10 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A10.png");
        InputStream streamB01 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B01.png");
        InputStream streamB02 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B02.png");
        InputStream streamB03 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B03.png");
        InputStream streamB04 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B04.png");
        InputStream streamB05 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B05.png");
        InputStream streamB06 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B06.png");
        InputStream streamB07 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B07.png");
        InputStream streamB08 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B08.png");
        InputStream streamB09 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B09.png");
        InputStream streamB10 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/B10.png");
        InputStream streamC01 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C01.png");
        InputStream streamC02 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C02.png");
        InputStream streamC03 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C03.png");
        InputStream streamC04 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C04.png");
        InputStream streamC05 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C05.png");
        InputStream streamC06 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C06.png");
        InputStream streamC07 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C07.png");
        InputStream streamC08 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C08.png");
        InputStream streamC09 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C09.png");
        InputStream streamC10 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/C10.png");
        InputStream streamD01 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D01.png");
        InputStream streamD02 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D02.png");
        InputStream streamD03 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D03.png");
        InputStream streamD04 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D04.png");
        InputStream streamD05 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D05.png");
        InputStream streamD06 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D06.png");
        InputStream streamD07 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D07.png");
        InputStream streamD08 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D08.png");
        InputStream streamD09 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D09.png");
        InputStream streamD10 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/D10.png");
        InputStream streamCardBack = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/cardback.png");
        InputStream streamCardBack1 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/cardback1.png");
        InputStream streamCardBack2 = new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/cardback2.png");


        isList.add( new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A01.png"));
        isList.add(new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A02.png"));
        isList.add( new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A03.png"));
        isList.add( new FileInputStream("/Users/zijiandong/Desktop/demo01/src/main/java/com/example/demo01/cards01/A04.png")) ;
        ImageView cardback = setImage(streamCardBack);
        ImageView cardback1 = setImage(streamCardBack1);
        ImageView cardback2 = setImage(streamCardBack2);

        SpotLight light = new SpotLight();
        light.setColor(Color.PURPLE);
        light.relocate(300,300);
        light.setRotate(45);


        cardback.relocate(250,300);
        cardback1.relocate(20,20);
        cardback2.relocate(700,600);
        // cardback.

        ArrayList<InputStream> arr = new ArrayList<InputStream>();
        arr.add(streamA01);
        arr.add(streamA02);
        arr.add(streamA03);
        arr.add(streamA04);
        arr.add(streamA05);
        arr.add(streamA06);
        arr.add(streamA07);
        arr.add(streamA08);
        arr.add(streamA09);
        arr.add(streamA10);
        arr.add(streamB01);
        arr.add(streamB02);
        arr.add(streamB03);
        arr.add(streamB04);
        arr.add(streamB05);
        arr.add(streamB06);
        arr.add(streamB07);
        arr.add(streamB08);
        arr.add(streamB09);
        arr.add(streamB10);
        arr.add(streamC01);
        arr.add(streamC02);
        arr.add(streamC03);
        arr.add(streamC04);
        arr.add(streamC05);
        arr.add(streamC06);
        arr.add(streamC07);
        arr.add(streamC08);
        arr.add(streamC09);
        arr.add(streamC10);
        arr.add(streamD01);
        arr.add(streamD02);
        arr.add(streamD03);
        arr.add(streamD04);
        arr.add(streamD05);
        arr.add(streamD06);
        arr.add(streamD07);
        arr.add(streamD08);
        arr.add(streamD09);
        arr.add(streamD10);
        System.out.println(arr.size());

        for(int j=0; j<40; j++){
            ImageViewList.add(setImage(arr.get(j)));
        }

        //Creating the image view

        ImageView firstcard =  ImageViewList.get(29);
        firstcard.relocate(300,300);
        firstcard.setRotate(90);
        HBox p1 = new HBox(3);
        HBox p2 = new HBox(3);

        HBox pile = new HBox(40);
        pile.setSpacing(-60);
        pile.setScaleX(cardWidth);
        pile.setScaleY(cardHeight);


        p1.getChildren().add(ImageViewList.get(3));
        p1.getChildren().add(ImageViewList.get(13));
        p1.getChildren().add(ImageViewList.get(23));
        p2.getChildren().add(ImageViewList.get(6));
        p2.getChildren().add(ImageViewList.get(8));
        p2.getChildren().add(ImageViewList.get(15));

/*
        pile.getChildren().remove(3);
        pile.getChildren().remove(13);
        pile.getChildren().remove(23);
        pile.getChildren().remove(6);
        pile.getChildren().remove(8);
        pile.getChildren().remove(15);
*/

        p1.getChildren().get(0).relocate(300,20);
        p1.getChildren().get(1).relocate(400,20);
        p1.getChildren().get(2).relocate(500,20);
        p2.getChildren().get(0).relocate(300,600);
        p2.getChildren().get(1).relocate(400,600);
        p2.getChildren().get(2).relocate(500,600);

        p1.getChildren().get(0).setRotate(20);
        p1.getChildren().get(2).setRotate(-20);
        p2.getChildren().get(0).setRotate(-20);
        p2.getChildren().get(2).setRotate(20);

        Group root = new Group();



        Scene scene = new Scene(root, 800, 800, tableColor);

        root.getChildren().addAll(cardback1,cardback2,firstcard,cardback,p1.getChildren().get(0),p1.getChildren().get(1),p1.getChildren().get(2),p2.getChildren().get(0),p2.getChildren().get(1),p2.getChildren().get(2));
        root.getChildren().forEach(this::makeDraggable);
      ///  layout1.getChildren().get(2).setLayoutX(500);
        pile.setBackground(Background.fill(tableColor));

        Label label0 = new Label("Main Menu");
        Label briscola = new Label("briscola");
        briscola.setMinSize(100,100);
        VBox layout0 = new VBox(20);
        Scene scene0 = new Scene(layout0,1000,1000);
        Button start = new Button("Start");
        start.setOnAction(e ->stage.setScene(scene));
        layout0.getChildren().addAll(start);
        layout0.setBackground(Background.fill(tableColor));



        //Setting the Scene object
        stage.setTitle("Briscola demo");
        stage.setScene(scene0);
        stage.show();
    }
    private void makeDraggable (Node node){
        node.setOnMousePressed(e -> {
            startX = e.getSceneX() - node.getTranslateX();
            startY = e.getSceneY() - node.getTranslateY();
        });
        node.setOnMouseDragged(e -> {
            node.setTranslateX(e.getSceneX() - startX);
            node.setTranslateY(e.getSceneY() - startY);

        });
    }
    public ImageView setImage (InputStream IS){
        Image image = new Image(IS);
        ImageView imageView = new ImageView();
        imageView.setImage(image);
        imageView.setFitWidth(cardWidth);
        imageView.setFitHeight(cardHeight);
        return imageView;
    }





}